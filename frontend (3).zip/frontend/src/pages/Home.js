import React, { useEffect, useState } from "react";
import axios from "axios";
import { Link, useParams } from "react-router-dom";

export default function Home() {
  const [users, setUsers] = useState([]);

  const { id } = useParams();


  useEffect(() => {
    loadUsers();
  }, []);

  const loadUsers = async () => {
    const result = await axios.get("http://localhost:8080/users");
    setUsers(result.data);
  };

  const deleteUser = async (id) => {
    await axios.delete(`http://localhost:8080/users/${id}`);
    loadUsers();
  };

  const toggleStatus = async (userId, currentStatus) => {
    // Toggle the status between 0 and 1
    const newStatus = currentStatus === 0 ? 1 : 0;
  
    try {
      if (currentStatus === 1) {
        await axios.put(`http://localhost:8080/users/${userId}`, { status: newStatus });
      } else {
        await axios.put(`http://localhost:8080/usersactive/${userId}`, { status: newStatus });
      }
      loadUsers();
    } catch (error) {
      console.error("Failed to toggle status:", error);
    }
  };
  

  return (
    <div className="container ">
      <div className="py-4">
        <table className="table border shadow">
          <thead>
            <tr>
              <th scope="col">S.N</th>
              <th scope="col">Name</th>
              <th scope="col">Username</th>
              <th scope="col">Email</th>
              <th scope="col">Age</th>
              <th scope="col">Action</th>
            </tr>
          </thead>
          <tbody>
            {users.map((user, index) => (
              <tr>
                <th scope="row" key={index}>
                  {index + 1}
                </th>
                <td style={{ color: user.status === 0 ? 'grey' : 'inherit' }}>{user.name}</td>
<td style={{ color: user.status === 0 ? 'grey' : 'inherit' }}>{user.username}</td>
<td style={{ color: user.status === 0 ? 'grey' : 'inherit' }}>{user.email}</td>
<td style={{ color: user.status === 0 ? 'grey' : 'inherit' }}>{user.age}</td>

                <td>
              <Link
  className={`btn btn-secondary mx-2 ${user.status === 0 ? "disabled" : ""}`}
  to={`/viewuser/${user.id}`}
>
  View
</Link>
<Link
  className={`btn btn-outline-secondary-emphasi mx-2 ${user.status === 0 ? "disabled" : ""}`}
  to={`/edituser/${user.id}`}
>
  Edit
</Link>
                  <button
                    className="btn btn-danger mx-2"
                    onClick={() => deleteUser(user.id)}
                  >
                    Delete
                  </button>

                  <button className="btn btn-danger mx-2" onClick={() => toggleStatus(user.id, user.status)}>
                        {user.status === 1 ? "Suspend" : "Active User"}
                     </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
